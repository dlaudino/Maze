import java.util.Random;
import java.util.Stack;

// Derek Laudino

public class Main {

	public static void main(String[] args) {

		Maze gettingMaze5 = new Maze(5,5, true);
		System.out.print(" Maze 5 X 5: " + "\n");
		gettingMaze5.showMaze();

		Maze gettingMaze10 = new Maze(10,15, false);
		System.out.print(" Maze 10 X 15: " + "\n");
		gettingMaze10.showMaze();

		
		
/*		Stack<int[]> shorts = new Stack<int[]>();
		int [] visitedBlock =  {3, 1}; 
		shorts.push(visitedBlock);
		int [] visitedBlock1 =  {4, 9}; 
		shorts.push(visitedBlock1);
		int [] visitedBlock2 =  {5, 2}; 
		shorts.push(visitedBlock2);
		int [] FinalPath = shorts.get(shorts.size()-1);
		int rowOfMaze = FinalPath[0];
		int colOfMaze = FinalPath[1];
		System.out.print( rowOfMaze + " " + colOfMaze + "\n");
		shorts.pop();
		int [] FinalPath1 = shorts.get(shorts.size()-1);
		int rowOfMaze1 = FinalPath1[0];
		int colOfMaze1 = FinalPath1[1];
		System.out.print( rowOfMaze1 + " " + colOfMaze1 + "\n");

*/		
		
	}

}
